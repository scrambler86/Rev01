﻿// MovementDebugOverlay.cs
using UnityEngine;

public class MovementDebugOverlay : MonoBehaviour
{
    [Header("Target da monitorare")]
    public PlayerControllerCore target;

    [Header("Schermo")]
    public Vector2 panelPos = new Vector2(10f, 10f);
    public float panelWidth = 260f;

    GUIStyle _boxStyle;
    GUIStyle _labelStyle;

    void Awake()
    {
        if (!target)
            target = FindObjectOfType<PlayerControllerCore>();
    }

    void BuildStylesIfNeeded()
    {
        if (_boxStyle != null && _labelStyle != null)
            return;

        _boxStyle = new GUIStyle(GUI.skin.box)
        {
            alignment = TextAnchor.UpperLeft,
            fontSize = 11,
            normal = { textColor = Color.white }
        };

        _labelStyle = new GUIStyle(GUI.skin.label)
        {
            alignment = TextAnchor.UpperLeft,
            fontSize = 11,
            normal = { textColor = Color.white }
        };
    }

    void OnGUI()
    {
        if (!target)
            return;

        BuildStylesIfNeeded();

        Rect r = new Rect(panelPos.x, panelPos.y, panelWidth, 120f);
        GUILayout.BeginArea(r, _boxStyle);
        GUILayout.Label("=== MOVEMENT DEBUG ===", _labelStyle);
        GUILayout.Label("RunToggle: " + (target.IsRunningToggle ? "RUN" : "WALK"), _labelStyle);
        GUILayout.Label("PlanarSpeed: " + target.DebugPlanarSpeed.ToString("F2") + " m/s", _labelStyle);
        GUILayout.Label("ClickToMove path? " + (GetHasPath(target) ? "YES" : "no"), _labelStyle);
        GUILayout.EndArea();
    }

    bool GetHasPath(PlayerControllerCore core)
    {
        var ctm = core.GetComponent<ClickToMoveAgent>();
        if (!ctm) return false;
        return ctm.HasPath;
    }
}