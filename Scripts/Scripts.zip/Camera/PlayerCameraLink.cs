﻿// PlayerCameraLink.cs
using UnityEngine;
using FishNet.Object;

public class PlayerCameraLink : NetworkBehaviour
{
    public override void OnStartClient()
    {
        base.OnStartClient();
        if (!IsOwner) return;

        var cam = Camera.main;
        if (!cam) return;

        // Assicura che la Main Camera abbia CameraFollow
        var follow = cam.GetComponent<CameraFollow>();
        if (!follow) follow = cam.gameObject.AddComponent<CameraFollow>();

        // Collega il target e centra subito la posa
        follow.target = transform;
        follow.SnapToTarget();
        follow.enabled = true;
    }
}