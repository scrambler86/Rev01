using UnityEngine;

public interface INetTime
{
    double Now();
}
