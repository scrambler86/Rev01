using System.Collections.Generic;
using UnityEngine;

namespace Network
{
    public class TemporalSnapshotBuffer<T>
    {
        public struct Entry
        {
            public T Data;
            public double Time;
        }

        private readonly List<Entry> _list = new List<Entry>(64);

        public void Add(T data, double time)
        {
            _list.Add(new Entry { Data = data, Time = time });
            if (_list.Count > 64)
                _list.RemoveAt(0);
        }

        public bool TryGetBracket(double renderTime, out Entry a, out Entry b)
        {
            a = default; b = default;
            if (_list.Count < 2) return false;

            int i = 0;
            while (i < _list.Count && _list[i].Time <= renderTime) i++;
            int r = Mathf.Clamp(i, 1, _list.Count - 1);
            int l = r - 1;
            a = _list[l];
            b = _list[r];
            return true;
        }
    }
}
