﻿// NetTimeFishNet.cs
using UnityEngine;
using FishNet;
using FishNet.Managing.Timing;

namespace Network.Adapters
{
    public class NetTimeFishNet : INetTime
    {
        public double Now()
        {
            var tm = InstanceFinder.TimeManager;
            if (tm == null)
                return Time.timeAsDouble;

            // Usa TickType.Tick per ottenere il tick corrente
            return tm.TicksToTime(tm.GetPreciseTick(FishNet.Managing.Timing.TickType.Tick));
        }
    }
}