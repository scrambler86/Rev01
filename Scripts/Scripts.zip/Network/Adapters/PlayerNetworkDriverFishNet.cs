﻿// PlayerNetworkDriverFishNet.cs
using UnityEngine;
using FishNet.Object;
using FishNet.Connection;
using FishNet;
using System.Collections.Generic;
using Network.Adapters;
using System;

[RequireComponent(typeof(PlayerControllerCore))]
[RequireComponent(typeof(Rigidbody))]
public class PlayerNetworkDriverFishNet : NetworkBehaviour
{
    PlayerControllerCore _core;
    Rigidbody _rb;
    INetTime _netTime;
    ClickToMoveAgent _ctm;

    uint _lastSeqSent;
    float _sendTimer;
    float _sendDt = 1f / 30f; // Adattato a tick rate comune; rendi configurabile

    struct Snapshot
    {
        public Vector3 pos;
        public Vector3 vel;
        public double serverTime;
        public uint seq;
    }

    readonly Queue<Snapshot> _buffer = new Queue<Snapshot>(64); // Buffer circolare
    double _interpDelay = 0.1; // Dinamico dopo

    const float DEADZONE = 0.12f;
    const float SNAPDIST = 0.65f;
    const float BLEND = 0.35f;
    Vector3 _reconcileTarget;
    Vector3 _reconcileVel;
    bool _reconcileActive;

    // Input buffer per reconciliation
    struct InputState
    {
        public Vector3 dir;
        public bool running;
        public uint seq;
        public Vector3 predictedPos;
    }
    readonly Queue<InputState> _inputBuffer = new Queue<InputState>(64);

    // Anti-cheat
    Vector3 _lastServerPos;
    float _maxSpeedTolerance = 1.1f; // Da config
    List<string> _log = new List<string>(); // Per event logging

    void Awake()
    {
        _core = GetComponent<PlayerControllerCore>();
        _rb = GetComponent<Rigidbody>();
        _ctm = GetComponent<ClickToMoveAgent>();
        _netTime = new NetTimeFishNet();

        // Carica config
        // MovementConfig config = Resources.Load<MovementConfig>("MovementConfig");
        // if (config) { _interpDelay = config.interpDelay; _sendDt = 1f / config.tickRate; ... }
    }

    public override void OnStartClient()
    {
        base.OnStartClient();
        bool owner = IsOwner;
        _core.SetAllowInput(owner);
        _rb.isKinematic = !owner;
        _rb.detectCollisions = owner;
        _rb.interpolation = owner ? RigidbodyInterpolation.Extrapolate : RigidbodyInterpolation.None;
    }

    void FixedUpdate()
    {
        if (!IsSpawned || !_core || !_rb) return;

        // Adatta interpDelay dinamico
        if (InstanceFinder.TimeManager != null)
            _interpDelay = Math.Max(0.05, InstanceFinder.TimeManager.RoundTripTime / 2000.0);

        if (IsOwner)
        {
            _sendTimer += Time.fixedDeltaTime;
            if (_sendTimer >= _sendDt)
            {
                _sendTimer = 0f;
                _lastSeqSent++;

                Vector3 pos = _rb.position;
                Vector3 dir = _core.DebugLastMoveDir;
                bool running = _core.IsRunning;
                bool isCTM = _ctm != null && _ctm.HasPath;
                Vector3[] pathCorners = isCTM ? _ctm.GetPathCorners() : null;

                CmdSendInput(dir, pos, running, _lastSeqSent, isCTM, pathCorners);

                // Buffer input per replay
                _inputBuffer.Enqueue(new InputState { dir = dir, running = running, seq = _lastSeqSent, predictedPos = pos });
                if (_inputBuffer.Count > 64) _inputBuffer.Dequeue();
            }

            if (_reconcileActive)
            {
                _rb.position = Vector3.SmoothDamp(_rb.position, _reconcileTarget, ref _reconcileVel, BLEND);
                if (Vector3.Distance(_rb.position, _reconcileTarget) < 0.02f)
                    _reconcileActive = false;
            }
        }
        else
        {
            if (_buffer.Count < 2)
            {
                // Extrapolation se buffer vuoto
                if (_buffer.Count == 1)
                {
                    Snapshot last = _buffer.Peek();
                    double dt = _netTime.Now() - last.serverTime;
                    transform.position = last.pos + last.vel * (float)dt;
                }
                return;
            }

            double now = _netTime.Now();
            double interpTime = now - _interpDelay;

            Snapshot A = default, B = default;
            bool found = false;
            Snapshot[] snaps = _buffer.ToArray();
            for (int i = 0; i < snaps.Length - 1; i++)
            {
                if (snaps[i].serverTime <= interpTime && snaps[i + 1].serverTime > interpTime)
                {
                    A = snaps[i];
                    B = snaps[i + 1];
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                // Extrapolate ultimo
                Snapshot last = snaps[snaps.Length - 1];
                double dt = interpTime - last.serverTime;
                transform.position = last.pos + last.vel * (float)dt;
                return;
            }

            double span = B.serverTime - A.serverTime;
            float t = (span > 1e-6) ? (float)((interpTime - A.serverTime) / span) : 1f;
            t = Mathf.Clamp01(t);

            // Hermite interpolation
            Vector3 derivA = A.vel * (float)span;
            Vector3 derivB = B.vel * (float)span;
            Vector3 interpPos = Hermite(A.pos, derivA, B.pos, derivB, t);
            transform.position = interpPos;

            // Pulisci vecchi
            while (_buffer.Count > 0 && _buffer.Peek().serverTime < interpTime - 0.2)
                _buffer.Dequeue();
        }
    }

    private Vector3 Hermite(Vector3 p0, Vector3 v0, Vector3 p1, Vector3 v1, float t)
    {
        float t2 = t * t;
        float t3 = t2 * t;
        return (2 * t3 - 3 * t2 + 1) * p0 + (t3 - 2 * t2 + t) * v0 + (-2 * t3 + 3 * t2) * p1 + (t3 - t2) * v1;
    }

    [ServerRpc]
    void CmdSendInput(Vector3 dir, Vector3 predictedPos, bool running, uint seq, bool isCTM, Vector3[] pathCorners)
    {
        // Validazione input anti-cheat
        float curSpeed = running ? _core.speed * _core.runMultiplier : _core.speed;
        Vector3 vel = dir.normalized * curSpeed;
        float distFromLast = Vector3.Distance(predictedPos, _lastServerPos);
        if (distFromLast > curSpeed * _sendDt * _maxSpeedTolerance)
        {
            _log.Add($"Suspicious move: dist={distFromLast}, seq={seq}");
            // Kick if too many: if (_log.Count > 10) Despawn();
            return; // Blocca
        }

        // Valida collision/NavMesh
        if (isCTM && pathCorners != null && pathCorners.Length > 0)
        {
            UnityEngine.AI.NavMeshPath path = new UnityEngine.AI.NavMeshPath();
            if (!UnityEngine.AI.NavMesh.CalculatePath(_rb.position, pathCorners[pathCorners.Length - 1], UnityEngine.AI.NavMesh.AllAreas, path))
                return; // Invalid path
            // Simula movimento lungo path
        }

        _rb.position = predictedPos;
        _lastServerPos = predictedPos;

        double serverTime = InstanceFinder.TimeManager != null
            ? InstanceFinder.TimeManager.TicksToTime(InstanceFinder.TimeManager.GetPreciseTick(FishNet.Managing.Timing.TickType.Tick))
            : Time.timeAsDouble;

        // Interest management: Invia solo a vicini
        // Es: List<NetworkConnection> nearby = GetNearbyConns();
        // foreach (var conn in nearby) TargetSnapshot(conn, predictedPos, vel, serverTime, seq);
        // Per ora, usa ObserversRpc con BufferLast

        RpcSnapshot(predictedPos, vel, serverTime, seq); // Todo: Replace with targeted

        TargetCorrection(Owner, seq, predictedPos);
    }

    [ObserversRpc(BufferLast = true)]
    void RpcSnapshot(Vector3 pos, Vector3 vel, double serverTime, uint seq)
    {
        if (IsOwner) return;

        if (_buffer.Count > 0 && seq <= _buffer.Peek().seq) return; // Out of order, but queue no reorder; todo: sort if needed

        _buffer.Enqueue(new Snapshot { pos = pos, vel = vel, serverTime = serverTime, seq = seq });
        if (_buffer.Count > 64) _buffer.Dequeue();
    }

    [TargetRpc]
    void TargetCorrection(NetworkConnection conn, uint seq, Vector3 serverPos)
    {
        if (!IsOwner) return;

        float err = Vector3.Distance(_rb.position, serverPos);
        if (err < DEADZONE) return;

        // Replay inputs su correction
        while (_inputBuffer.Count > 0 && _inputBuffer.Peek().seq < seq)
            _inputBuffer.Dequeue();

        Vector3 correctedPos = serverPos;
        foreach (var input in _inputBuffer)
        {
            // Replay: Simula movimento con input su correctedPos
            float curSpeed = input.running ? _core.speed * _core.runMultiplier : _core.speed;
            Vector3 vel = input.dir.normalized * curSpeed;
            correctedPos += vel * Time.fixedDeltaTime; // Approssimato; usa full sim se necessario
        }

        if (err > SNAPDIST) _rb.position = correctedPos;
        else
        {
            _reconcileTarget = correctedPos;
            _reconcileActive = true;
        }
    }

    // Todo: GetNearbyConns() per interest management
    // Use Physics.OverlapSphere(transform.position, viewRadius, playerLayer);
}